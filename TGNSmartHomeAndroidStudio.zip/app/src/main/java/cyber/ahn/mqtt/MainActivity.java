package cyber.ahn.mqtt;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.TextView;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttMessage;

public class MainActivity extends AppCompatActivity {
    MqttHelper mqttHelper;
    TextView versionReceived;
    TextView ipReceived;
    TextView WtempReceived;
    TextView WhumReceived;
    TextView WcloudReceived;
    TextView WwindReceived;
    TextView langReceived;
    TextView clientReceived;
    TextView blockReceived;
    TextView querReceived;
    TextView roomReceived;
    TextView luxReceived;
    TextView mcpReceived;
    TextView lcdReceived;
    TextView rtcReceived;
    TextView romReceived;
    TextView b1namReceived;
    TextView b1statReceived;
    TextView b2namReceived;
    TextView b2statReceived;
    TextView b3namReceived;
    TextView b3statReceived;
    TextView b4namReceived;
    TextView b4statReceived;
    TextView b5namReceived;
    TextView b5statReceived;
    TextView b6namReceived;
    TextView b6statReceived;
    TextView eipReceived;
    TextView etempReceived;
    TextView ehumReceived;
    TextView elightReceived;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        versionReceived = findViewById(R.id.versionReceived);
        ipReceived = findViewById(R.id.ipReceived);
        WtempReceived = findViewById(R.id.WtempReceived);
        WhumReceived = findViewById(R.id.WhumReceived);
        WcloudReceived = findViewById(R.id.WcloudReceived);
        WwindReceived = findViewById(R.id.WwindReceived);
        langReceived = findViewById(R.id.langReceived);
        clientReceived = findViewById(R.id.clientReceived);
        blockReceived = findViewById(R.id.blockReceived);
        querReceived = findViewById(R.id.querReceived);
        roomReceived = findViewById(R.id.roomReceived);
        luxReceived = findViewById(R.id.luxReceived);
        mcpReceived = findViewById(R.id.mcpReceived);
        lcdReceived = findViewById(R.id.lcdReceived);
        rtcReceived = findViewById(R.id.rtcReceived);
        romReceived = findViewById(R.id.romReceived);
        b1namReceived = findViewById(R.id.b1namReceived);
        b1statReceived = findViewById(R.id.b1statReceived);
        b2namReceived = findViewById(R.id.b2namReceived);
        b2statReceived = findViewById(R.id.b2statReceived);
        b3namReceived = findViewById(R.id.b3namReceived);
        b3statReceived = findViewById(R.id.b3statReceived);
        b4statReceived = findViewById(R.id.b4statReceived);
        b4namReceived = findViewById(R.id.b4namReceived);
        b5statReceived = findViewById(R.id.b5statReceived);
        b5namReceived = findViewById(R.id.b5namReceived);
        b6statReceived = findViewById(R.id.b6statReceived);
        b6namReceived = findViewById(R.id.b6namReceived);
        eipReceived = findViewById(R.id.eipReceived);
        etempReceived = findViewById(R.id.etempReceived);
        ehumReceived = findViewById(R.id.ehumReceived);
        elightReceived = findViewById(R.id.elightReceived);
        startMqtt();
    }

    private void startMqtt(){
        mqttHelper = new MqttHelper(getApplicationContext());
        mqttHelper.setCallback(new MqttCallbackExtended() {
            @Override
            public void connectComplete(boolean b, String s) {

            }
            @Override
            public void connectionLost(Throwable throwable) {

            }
            @Override
            public void messageArrived(String topic, MqttMessage mqttMessage) {
                Log.w("Debug",mqttMessage.toString());
                final String ontext = "On";
                final String offtext = "Off";
                if (topic.equals("tgn/version")){
                    versionReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/ip")){
                    ipReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/weather/temp")){
                    WtempReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/weather/humidity")){
                    WhumReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/weather/clouds")){
                    WcloudReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/weather/wind")){
                    WwindReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/language")){
                    langReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/pihole/clients")){
                    clientReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/pihole/adBlock")){
                    blockReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/pihole/queries")){
                    querReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/room/temp")){
                    roomReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/room/light")){
                    luxReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/i2c/mcp")){
                    mcpReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/i2c/lcd")){
                    lcdReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/i2c/rtc")){
                    rtcReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/i2c/eeprom")){
                    romReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/buttons/name/1")){
                    b1namReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/buttons/status/1")){
                    if (mqttMessage.toString().equals("1")) {
                        b1statReceived.setText(ontext);
                    }
                    else {
                        b1statReceived.setText(offtext);
                    }
                }
                if (topic.equals("tgn/buttons/name/2")){
                    b2namReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/buttons/status/2")){
                    if (mqttMessage.toString().equals("1")) {
                        b2statReceived.setText(ontext);
                    }
                    else {
                        b2statReceived.setText(offtext);
                    }
                }
                if (topic.equals("tgn/buttons/name/3")){
                    b3namReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/buttons/status/3")){
                    if (mqttMessage.toString().equals("1")) {
                        b3statReceived.setText(ontext);
                    }
                    else {
                        b3statReceived.setText(offtext);
                    }
                }
                if (topic.equals("tgn/buttons/name/4")){
                    b4namReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/buttons/status/4")){
                    if (mqttMessage.toString().equals("1")) {
                        b4statReceived.setText(ontext);
                    }
                    else {
                        b4statReceived.setText(offtext);
                    }
                }
                if (topic.equals("tgn/buttons/name/5")){
                    b5namReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/buttons/status/5")){
                    if (mqttMessage.toString().equals("1")) {
                        b5statReceived.setText(ontext);
                    }
                    else {
                        b5statReceived.setText(offtext);
                    }
                }
                if (topic.equals("tgn/buttons/name/6")){
                    b6namReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/buttons/status/6")){
                    if (mqttMessage.toString().equals("1")) {
                        b6statReceived.setText(ontext);
                    }
                    else {
                        b6statReceived.setText(offtext);
                    }
                }
                if (topic.equals("tgn/esp_1/connection/ip")){
                    eipReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/esp_1/temp/sensor_1")){
                    etempReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/esp_1/temp/sensor_2")){
                    ehumReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/esp_1/analog/sensor_1")){
                    elightReceived.setText(mqttMessage.toString());
                }
            }
            @Override
            public void deliveryComplete(IMqttDeliveryToken iMqttDeliveryToken) {
            }
        });
    }
}
