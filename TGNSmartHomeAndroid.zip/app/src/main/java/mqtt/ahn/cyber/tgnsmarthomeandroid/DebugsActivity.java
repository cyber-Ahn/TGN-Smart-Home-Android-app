package mqtt.ahn.cyber.tgnsmarthomeandroid;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttMessage;



public class DebugsActivity extends Activity {

    TextView textdeb;
    TextView textMod;
    TextView textIP;
    MqttHelper mqttHelper;
    public String clientId = "AndroidClient";
    public String serverUri = "tcp://192.168.0.0:1883";
    public int sendid = 666;
    public String mo = "";
    public String ver = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_debug);
        textdeb = findViewById(R.id.textdeb);
        textMod = findViewById(R.id.textModel);
        textIP = findViewById(R.id.textIp);
        textdeb.setMovementMethod(new ScrollingMovementMethod());
        SharedPreferences mySPR = getSharedPreferences("MySPFILE",0);
        serverUri = mySPR.getString("0096","tcp://192.168.0.1:1883");
        textdeb.setText(serverUri);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        startMqtt();
    }

    @Override
    protected void onPause() {
        super.onPause();
        Toast.makeText(getApplicationContext(), "Stop Mqtt reciver", Toast.LENGTH_LONG).show();
        finish();
        System.exit(0);
    }

    private void startMqtt() {
        mqttHelper = new MqttHelper(getApplicationContext(), serverUri, clientId);
        final Button button1 = this.findViewById(R.id.backbutton);
        final Button button2 = this.findViewById(R.id.btnwlan);
        button1.setOnClickListener(
                new Button.OnClickListener(){
                    public void onClick(View v){
                        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                        Intent activityintent = new Intent(DebugsActivity.this, MainActivity.class);
                        startActivityForResult(activityintent, sendid);
                    }
                }
        );
        button2.setOnClickListener(
                new Button.OnClickListener(){
                    public void onClick(View v){
                        mqttHelper.messagePublish("tgn/system/reboot/bot","1");
                        mqttHelper.messagePublish("tgn/bot/status","offline");
                        mqttHelper.messagePublish("tgn/system/reboot/esp1","1");
                        mqttHelper.messagePublish("tgn/system/reboot/esp2","1");
                        mqttHelper.messagePublish("tgn/system/reboot/esp3","1");
                        mqttHelper.messagePublish("tgn/system/reboot/cam","1");
                        Toast.makeText(getApplicationContext(), "W-LAN Reset", Toast.LENGTH_LONG).show();
                    }
                }
        );
        mqttHelper.setCallback(new MqttCallbackExtended() {
            @Override
            public void connectComplete(boolean b, String s) {
            }
            @Override
            public void connectionLost(Throwable throwable) {
            }
            @SuppressLint("SetTextI18n")
            @Override
            public void messageArrived(String topic, MqttMessage mqttMessage) {
                    textdeb.append("\n"+topic +" - "+mqttMessage.toString());
                    textdeb.setMovementMethod(new ScrollingMovementMethod());
                if (topic.equals("tgn/android/ip")){
                    textIP.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/android/name")){
                    mo = mqttMessage.toString();
                }
                if (topic.equals("tgn/android/version")){
                    ver = mqttMessage.toString();
                }
                textMod.setText(mo + "("+ver+")");
            }
            @Override
            public void deliveryComplete(IMqttDeliveryToken iMqttDeliveryToken) {
            }
        });
    }
}
