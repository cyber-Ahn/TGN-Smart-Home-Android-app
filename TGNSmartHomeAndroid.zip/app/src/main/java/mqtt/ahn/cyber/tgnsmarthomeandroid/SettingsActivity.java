package mqtt.ahn.cyber.tgnsmarthomeandroid;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class SettingsActivity extends Activity implements View.OnClickListener {
    public Button btnSettings;
    public EditText ipsend;
    public TextView settingsText;
    public TextView txBTN;
    public String ettext;
    public int sendid = 444;
    public String col_set = "1";
    public String btn_cach = "0";
    public String btn_cach_2 = "0";
    Switch switch1;
    Switch switch2;
    boolean pressedOnce;
    public boolean onKeyDown(int keyCode, KeyEvent event){
        if(keyCode == KeyEvent.KEYCODE_BACK){
            if(!pressedOnce){
                pressedOnce = true;
                Toast.makeText(getApplicationContext(),"Press twice to exit", Toast.LENGTH_SHORT).show();
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        pressedOnce = false;
                    }
                }, 3000);
            }
            else {
                pressedOnce = false;
                onBackPressed();
                finish();
                System.exit(0);
            }
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        btnSettings = findViewById(R.id.btnSettings);
        settingsText = findViewById(R.id.settingsText);
        btnSettings.setOnClickListener(this);
        ipsend = findViewById(R.id.ipsend);
        switch1 = findViewById(R.id.switch1);
        switch2 = findViewById(R.id.switch2);
        txBTN =findViewById(R.id.txBTN);
        txBTN.setText(R.string.txt_btn_1_c);
        SharedPreferences mySPR = getSharedPreferences("MySPFILE",0);
        ipsend.setText(mySPR.getString("0096","tcp://192.168.0.1:1883"));
        col_set = mySPR.getString("color","0");
        if(col_set.equals("1"))
        {
            settingsText.setTextColor(getResources().getColor(R.color.text2));
            btnSettings.setBackgroundColor(getResources().getColor(R.color.btn2));
        }
        switch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    btn_cach = "1";
                    txBTN.setText(R.string.txt_theme_o);
                }
                else{
                    btn_cach = "0";
                    txBTN.setText(R.string.txt_theme_n);
                }
            }
        });
        switch2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    btn_cach_2 = "1";
                }
                else{
                    btn_cach_2 = "0";
                }
            }
        });

    }
    @Override
    public void onClick(View v){
        switch(v.getId()){
            case R.id.btnSettings:{
                if(ipsend.getText().toString().length() > 0) {
                    ettext = ipsend.getText().toString();
                    Intent activityintent = new Intent(SettingsActivity.this, MainActivity.class);
                    activityintent.putExtra("brockerIP", ettext);
                    activityintent.putExtra("theme", btn_cach);
                    activityintent.putExtra("nachr", btn_cach_2);
                    startActivityForResult(activityintent, sendid);
                }
                else {
                    Toast.makeText(getApplicationContext(),"Enter Address !", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }
}