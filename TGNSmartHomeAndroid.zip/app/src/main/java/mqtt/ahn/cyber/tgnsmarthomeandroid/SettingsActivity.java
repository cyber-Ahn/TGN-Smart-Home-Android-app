package mqtt.ahn.cyber.tgnsmarthomeandroid;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SettingsActivity extends Activity implements View.OnClickListener {
    public Button btnSettings;
    public EditText ipsend;
    public String ettext;
    public int sendid = 444;
    boolean pressedOnce;
    public boolean onKeyDown(int keyCode, KeyEvent event){
        if(keyCode == KeyEvent.KEYCODE_BACK){
            if(!pressedOnce){
                pressedOnce = true;
                Toast.makeText(getApplicationContext(),"Press twice to exit", Toast.LENGTH_SHORT).show();
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        pressedOnce = false;
                    }
                }, 3000);
            }
            else {
                pressedOnce = false;
                onBackPressed();
                finish();
                System.exit(0);
            }
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        btnSettings = findViewById(R.id.btnSettings);
        btnSettings.setOnClickListener(this);
        ipsend = findViewById(R.id.ipsend);
        SharedPreferences mySPR = getSharedPreferences("MySPFILE",0);
        ipsend.setText(mySPR.getString("0096","tcp://192.168.0.1:1883"));
    }
    @Override
    public void onClick(View v){
        switch(v.getId()){
            case R.id.btnSettings:{
                if(ipsend.getText().toString().length() > 0) {
                    ettext = ipsend.getText().toString();
                    Intent activityintent = new Intent(SettingsActivity.this, MainActivity.class);
                    activityintent.putExtra("brockerIP", ettext);
                    startActivityForResult(activityintent, sendid);
                }
                else {
                    Toast.makeText(getApplicationContext(),"Enter Address !", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }
}