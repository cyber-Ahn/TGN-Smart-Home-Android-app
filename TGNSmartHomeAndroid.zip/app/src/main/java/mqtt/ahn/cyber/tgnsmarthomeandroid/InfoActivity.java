package mqtt.ahn.cyber.tgnsmarthomeandroid;

import android.app.Activity;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttMessage;

public class InfoActivity  extends Activity {
    public String serverUri = "tcp://192.168.0.0:1883";
    public String clientId = "AndroidClient";
    public String col_set = "1";
    MqttHelper mqttHelper;
    TextView textView100;
    TextView textView101;
    TextView textView102;
    TextView textView103;
    TextView textView104;
    TextView textView105;
    TextView textView106;
    TextView textView107;
    TextView textView108;
    TextView textView109;
    TextView textView110;
    TextView textView111;
    TextView textView112;
    TextView textView113;
    TextView textView114;
    TextView textView115;
    TextView textView116;
    TextView textView117;
    TextView textView118;
    TextView textView119;
    TextView textView120;
    public int sendid = 555;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);
        textView100 = findViewById(R.id.textView100);
        textView101 = findViewById(R.id.textView101);
        textView102 = findViewById(R.id.textView102);
        textView103 = findViewById(R.id.textView103);
        textView104 = findViewById(R.id.textView104);
        textView105 = findViewById(R.id.textView105);
        textView106 = findViewById(R.id.textView106);
        textView107 = findViewById(R.id.textView107);
        textView108 = findViewById(R.id.textView108);
        textView109 = findViewById(R.id.textView109);
        textView110 = findViewById(R.id.textView110);
        textView111 = findViewById(R.id.textView111);
        textView112 = findViewById(R.id.textView112);
        textView113 = findViewById(R.id.textView113);
        textView114 = findViewById(R.id.textView114);
        textView115 = findViewById(R.id.textView115);
        textView116 = findViewById(R.id.textView116);
        textView117 = findViewById(R.id.textView117);
        textView118 = findViewById(R.id.textView118);
        textView119 = findViewById(R.id.textView119);
        textView120 = findViewById(R.id.textView120);
        SharedPreferences mySPR = getSharedPreferences("MySPFILE",0);
        serverUri = mySPR.getString("0096","tcp://192.168.0.1:1883");
        col_set = mySPR.getString("color","0");
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        startMqtt();
    }
    private void startMqtt() {
        mqttHelper = new MqttHelper(getApplicationContext(), serverUri, clientId);
        final Button button1 = this.findViewById(R.id.backbuttonb);
        if(col_set.equals("1"))
        {
            textView100.setTextColor(getResources().getColor(R.color.text2));
            textView101.setTextColor(getResources().getColor(R.color.text2));
            textView102.setTextColor(getResources().getColor(R.color.text2));
            textView103.setTextColor(getResources().getColor(R.color.text2));
            textView104.setTextColor(getResources().getColor(R.color.text2));
            textView105.setTextColor(getResources().getColor(R.color.text2));
            textView106.setTextColor(getResources().getColor(R.color.text2));
            textView107.setTextColor(getResources().getColor(R.color.text2));
            textView108.setTextColor(getResources().getColor(R.color.text2));
            textView109.setTextColor(getResources().getColor(R.color.text2));
            textView110.setTextColor(getResources().getColor(R.color.text2));
            textView111.setTextColor(getResources().getColor(R.color.text2));
            textView112.setTextColor(getResources().getColor(R.color.text2));
            textView113.setTextColor(getResources().getColor(R.color.text2));
            textView114.setTextColor(getResources().getColor(R.color.text2));
            textView115.setTextColor(getResources().getColor(R.color.text2));
            textView116.setTextColor(getResources().getColor(R.color.text2));
            textView117.setTextColor(getResources().getColor(R.color.text2));
            textView118.setTextColor(getResources().getColor(R.color.text2));
            textView119.setTextColor(getResources().getColor(R.color.text2));
            textView120.setTextColor(getResources().getColor(R.color.text2));
            button1.setBackgroundColor(getResources().getColor(R.color.btn2));
        }
        button1.setOnClickListener(
                v -> {
                    getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    Intent activityintent = new Intent(InfoActivity.this, MainActivity.class);
                    startActivityForResult(activityintent, sendid);
                }
        );
        mqttHelper.setCallback(new MqttCallbackExtended() {
            @Override
            public void connectComplete(boolean b, String s) {
            }

            @Override
            public void connectionLost(Throwable throwable) {
            }

            @SuppressLint("SetTextI18n")
            @Override
            public void messageArrived(String topic, MqttMessage mqttMessage) {
                if (topic.equals("tgn/info/release")) {
                    textView101.setText("Release:  " + mqttMessage.toString());
                }
                if (topic.equals("tgn/info/architecture")) {
                    textView102.setText("Architecture:  " + mqttMessage.toString());
                }
                if (topic.equals("tgn/info/platform")) {
                    textView103.setText("Platform:  " + mqttMessage.toString());
                }
                if (topic.equals("tgn/info/node")) {
                    textView104.setText("Node:  " + mqttMessage.toString());
                }
                if (topic.equals("tgn/info/model")) {
                    textView105.setText("Model:  " + mqttMessage.toString());
                }
                if (topic.equals("tgn/info/boot-time")) {
                    textView106.setText("Boot Time:  " + mqttMessage.toString());
                }
                if (topic.equals("tgn/info/processes")) {
                    textView107.setText("Running Processes:  " + mqttMessage.toString());
                }
                if (topic.equals("tgn/info/python")) {
                    textView108.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/info/memory/present")) {
                    textView110.setText("Present:  " + mqttMessage.toString());
                }
                if (topic.equals("tgn/info/memory/available")) {
                    textView111.setText("Available:  " + mqttMessage.toString());
                }
                if (topic.equals("tgn/info/memory/used")) {
                    textView112.setText("Used:  " + mqttMessage.toString());
                }
                if (topic.equals("tgn/info/memory/precent")) {
                    textView113.setText("Precent:  " + mqttMessage.toString());
                }
                if (topic.equals("tgn/info/disk/device")) {
                    textView115.setText("Device:  " + mqttMessage.toString());
                }
                if (topic.equals("tgn/info/disk/file-sys")) {
                    textView116.setText("File-System:  " + mqttMessage.toString());
                }
                if (topic.equals("tgn/info/disk/total")) {
                    textView117.setText("Total:  " + mqttMessage.toString());
                }
                if (topic.equals("tgn/info/disk/free")) {
                    textView118.setText("Free:  " + mqttMessage.toString());
                }
                if (topic.equals("tgn/info/disk/used")) {
                    textView119.setText("Used:  " + mqttMessage.toString());
                }
                if (topic.equals("tgn/info/disk/precent")) {
                    textView120.setText("Precent:  " + mqttMessage.toString());
                }
            }
            @Override
            public void deliveryComplete(IMqttDeliveryToken iMqttDeliveryToken) {
            }
        });
    }
}
