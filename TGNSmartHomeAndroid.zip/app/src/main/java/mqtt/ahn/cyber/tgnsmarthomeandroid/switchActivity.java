package mqtt.ahn.cyber.tgnsmarthomeandroid;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttMessage;

public class switchActivity  extends Activity {

    public String serverUri = "tcp://192.168.0.0:1883";
    public String clientId = "AndroidClient";
    public String incomdata = "xxxx";
    MqttHelper mqttHelper;
    public int sendid = 837;
    public String col_set = "1";
    public String out = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_switch);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        final Bundle intentinput = getIntent().getExtras();
        if(intentinput != null){
            incomdata = intentinput.getString("brockerIP");
            if (incomdata == null){
                incomdata = "xxxx";
            }
            if(!incomdata.equals("xxxx")){
                SharedPreferences mySPR = getSharedPreferences("MySPFILE",0);
                SharedPreferences.Editor editor = mySPR.edit();
                editor.putString("0096", incomdata);
                editor.apply();
            }
        }
        SharedPreferences mySPR = getSharedPreferences("MySPFILE",0);
        serverUri = mySPR.getString("0096","tcp://192.168.0.1:1883");
        col_set = mySPR.getString("color","0");
        startMqtt();
    }
    @SuppressLint("SetTextI18n")
    private void startMqtt() {
        mqttHelper = new MqttHelper(getApplicationContext(), serverUri, clientId);
        final Button button1 = this.findViewById(R.id.backbutton);
        final Button btc_0 = this.findViewById(R.id.btc_0);
        final Button btc_1 = this.findViewById(R.id.btc_1);
        final Button btc_2 = this.findViewById(R.id.btc_2);
        final Button btc_3 = this.findViewById(R.id.btc_3);
        final Button btc_4 = this.findViewById(R.id.btc_4);
        final Button btc_5 = this.findViewById(R.id.btc_5);
        final Button btc_6 = this.findViewById(R.id.btc_6);
        final Button btc_7 = this.findViewById(R.id.btc_7);
        final Button btc_8 = this.findViewById(R.id.btc_8);
        final Button btc_9 = this.findViewById(R.id.btc_9);
        final Button btc_r = this.findViewById(R.id.btc_r);
        final Button btc_e = this.findViewById(R.id.btc_e);
        final TextView textinput = this.findViewById((R.id.textinput));
        if(col_set.equals("1"))
        {
            button1.setBackgroundColor(getResources().getColor(R.color.btn2));
            btc_0.setBackgroundColor(getResources().getColor(R.color.btn2));
            btc_1.setBackgroundColor(getResources().getColor(R.color.btn2));
            btc_2.setBackgroundColor(getResources().getColor(R.color.btn2));
            btc_3.setBackgroundColor(getResources().getColor(R.color.btn2));
            btc_4.setBackgroundColor(getResources().getColor(R.color.btn2));
            btc_5.setBackgroundColor(getResources().getColor(R.color.btn2));
            btc_6.setBackgroundColor(getResources().getColor(R.color.btn2));
            btc_7.setBackgroundColor(getResources().getColor(R.color.btn2));
            btc_8.setBackgroundColor(getResources().getColor(R.color.btn2));
            btc_9.setBackgroundColor(getResources().getColor(R.color.btn2));
            btc_e.setBackgroundColor(getResources().getColor(R.color.btn2));
            btc_r.setBackgroundColor(getResources().getColor(R.color.btn2));

        }
        button1.setOnClickListener(
                v -> {
                    getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    Intent activityintent = new Intent(switchActivity.this, MainActivity.class);
                    startActivityForResult(activityintent, sendid);
                }
        );
        btc_0.setOnClickListener(
                v -> {
                    out += "0";
                    textinput.setText(out);
                }
        );
        btc_1.setOnClickListener(
                v -> {
                    out += "1";
                    textinput.setText(out);
                }
        );
        btc_2.setOnClickListener(
                v -> {
                    out += "2";
                    textinput.setText(out);
                }
        );
        btc_3.setOnClickListener(
                v -> {
                    out += "3";
                    textinput.setText(out);
                }
        );
        btc_4.setOnClickListener(
                v -> {
                    out += "4";
                    textinput.setText(out);
                }
        );
        btc_5.setOnClickListener(
                v -> {
                    out += "5";
                    textinput.setText(out);
                }
        );
        btc_6.setOnClickListener(
                v -> {
                    out += "6";
                    textinput.setText(out);
                }
        );
        btc_7.setOnClickListener(
                v -> {
                    out += "7";
                    textinput.setText(out);
                }
        );
        btc_8.setOnClickListener(
                v -> {
                    out += "8";
                    textinput.setText(out);
                }
        );
        btc_9.setOnClickListener(
                v -> {
                    out += "9";
                    textinput.setText(out);
                }
        );
        btc_r.setOnClickListener(
                v -> {
                    out = "";
                    textinput.setText("xxxx");
                }
        );
        btc_e.setOnClickListener(
                v -> {
                    mqttHelper.messagePublish("tgn/codeswitch/data",out);
                    out = "";
                    textinput.setText("xxxx");
                }
        );
        mqttHelper.setCallback(new MqttCallbackExtended() {
            @Override
            public void connectComplete(boolean b, String s) {
            }

            @Override
            public void connectionLost(Throwable throwable) {
            }

            @SuppressLint("SetTextI18n")
            @Override
            public void messageArrived(String topic, MqttMessage mqttMessage) {
                String cach = mqttMessage.toString();
                if (topic.equals("tgn/codeswitch/msg")) {
                    if(!cach.equals("empty")) {
                        textinput.setText(cach);
                        mqttHelper.messagePublish("tgn/codeswitch/msg","empty");
                    }
                }
            }
            @Override
            public void deliveryComplete(IMqttDeliveryToken iMqttDeliveryToken) {
            }
        });
    }
}
