package mqtt.ahn.cyber.tgnsmarthomeandroid;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import yuku.ambilwarna.AmbilWarnaDialog;


public class NeoPixelActivity extends Activity {

    int mDefaultColor;
    Button mButton;
    Button ani_a;
    Button ani_b;
    Button ani_c;
    Button l_off;
    Button colA;
    Button colB;
    Button colC;
    Button neo2;
    public TextView colortext;
    public int sendid = 777;
    public SeekBar sb1;
    public TextView textbar;
    public TextView nodeip;
    public TextView textView42;
    public TextView textView40;
    int sbValue;
    int sbmax = 255;
    int sbstart = 50;
    public String serverUri = "tcp://192.168.0.0:1883";
    public String clientId = "AndroidClient";
    public String col_set = "1";
    MqttHelper mqttHelper;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_neopixel);
        sb1 = findViewById(R.id.seekBar);
        textbar = findViewById(R.id.textView41);
        mButton = findViewById(R.id.color);
        ani_a = findViewById(R.id.aniA);
        ani_b = findViewById(R.id.aniB);
        ani_c = findViewById(R.id.aniC);
        l_off = findViewById(R.id.button_off);
        colA = findViewById(R.id.col_a);
        colB = findViewById(R.id.col_b);
        colC = findViewById(R.id.col_c);
        colortext = findViewById(R.id.textView43);
        nodeip = findViewById(R.id.textView44);
        textView40 = findViewById(R.id.textView40);
        textView42 = findViewById(R.id.textView42);
        neo2 = findViewById(R.id.bu_neo2);
        sb1.setMax(sbmax);
        sb1.setProgress(sbstart);
        textbar.setText(Integer.toString(sbstart));
        SharedPreferences mySPR = getSharedPreferences("MySPFILE",0);
        serverUri = mySPR.getString("0096","tcp://192.168.0.1:1883");
        col_set = mySPR.getString("color","0");
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        startMqtt();
    }

    public void openColorPicker(){
        AmbilWarnaDialog colorPicker = new AmbilWarnaDialog(this, mDefaultColor, new AmbilWarnaDialog.OnAmbilWarnaListener() {
            @Override
            public void onCancel(AmbilWarnaDialog dialog) {
            }
            @Override
            public void onOk(AmbilWarnaDialog dialog, int color) {
                mDefaultColor = color;
                mqttHelper.messagePublish("tgn/esp_3/neopixel/color_cach",Integer.toString(mDefaultColor));
                int red = Color.red(mDefaultColor);
                int green = Color.green(mDefaultColor);
                int blue = Color.blue(mDefaultColor);
                int alpha = Color.alpha(mDefaultColor);
                String sen;
                sen = Integer.toString(red) + '.' + Integer.toString(green) + '.' + Integer.toString(blue) + '.' + Integer.toString(alpha);
                colortext.setText(sen);
                mqttHelper.messagePublish("tgn/esp_3/neopixel/color",sen);
            }
        });
        colorPicker.show();

    }

    private void startMqtt() {
        mqttHelper = new MqttHelper(getApplicationContext(), serverUri, clientId);
        final Button button1 = this.findViewById(R.id.backbuttonb);
        if(col_set.equals("1"))
        {
            colortext.setTextColor(getResources().getColor(R.color.text2));
            textbar.setTextColor(getResources().getColor(R.color.text2));
            nodeip.setTextColor(getResources().getColor(R.color.text2));
            textView40.setTextColor(getResources().getColor(R.color.text2));
            textView42.setTextColor(getResources().getColor(R.color.text2));
            l_off.setBackgroundColor(getResources().getColor(R.color.btn2));
            neo2.setBackgroundColor(getResources().getColor(R.color.btn2));
            colA.setBackgroundColor(getResources().getColor(R.color.btn2));
            colB.setBackgroundColor(getResources().getColor(R.color.btn2));
            colC.setBackgroundColor(getResources().getColor(R.color.btn2));
            ani_a.setBackgroundColor(getResources().getColor(R.color.btn2));
            ani_b.setBackgroundColor(getResources().getColor(R.color.btn2));
            ani_c.setBackgroundColor(getResources().getColor(R.color.btn2));
            mButton.setBackgroundColor(getResources().getColor(R.color.btn2));
            button1.setBackgroundColor(getResources().getColor(R.color.btn2));
        }
        button1.setOnClickListener(
                new Button.OnClickListener() {
                    public void onClick(View v) {
                        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                        Intent activityintent = new Intent(NeoPixelActivity.this, MainActivity.class);
                        startActivityForResult(activityintent, sendid);
                    }
                }
        );
        mButton.setOnClickListener(
                new Button.OnClickListener(){
                    public void onClick(View v){
                        mqttHelper.messagePublish("tgn/esp_3/neopixel/setneo","nothing");
                        Toast.makeText(getApplicationContext(), "Colorpicker", Toast.LENGTH_LONG).show();
                        openColorPicker();
                    }
                }
        );
        neo2.setOnClickListener(
                new Button.OnClickListener(){
                    public void onClick(View v){
                        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                        Intent activityintent = new Intent(NeoPixelActivity.this, NeoPixel2Activity.class);
                        startActivityForResult(activityintent, sendid);
                    }
                }
        );
        ani_a.setOnClickListener(
                new Button.OnClickListener(){
                    public void onClick(View v){
                        mqttHelper.messagePublish("tgn/esp_3/neopixel/setneo","nothing");
                        mqttHelper.messagePublish("tgn/esp_3/neopixel/mode","normal");
                        Toast.makeText(getApplicationContext(), "Set Mode Normal", Toast.LENGTH_LONG).show();
                    }
                }
        );
        ani_b.setOnClickListener(
                new Button.OnClickListener(){
                    public void onClick(View v){
                        mqttHelper.messagePublish("tgn/esp_3/neopixel/setneo","nothing");
                        mqttHelper.messagePublish("tgn/esp_3/neopixel/mode","rainbow");
                        Toast.makeText(getApplicationContext(), "Set Mode Rainbow", Toast.LENGTH_LONG).show();
                    }
                }
        );
        ani_c.setOnClickListener(
                new Button.OnClickListener(){
                    public void onClick(View v){
                        mqttHelper.messagePublish("tgn/esp_3/neopixel/setneo","nothing");
                        mqttHelper.messagePublish("tgn/esp_3/neopixel/mode","theater");
                        Toast.makeText(getApplicationContext(), "Set Mode Theater", Toast.LENGTH_LONG).show();
                    }
                }
        );
        l_off.setOnClickListener(
                new Button.OnClickListener(){
                    public void onClick(View v){
                        mqttHelper.messagePublish("tgn/esp_3/neopixel/setneo","nothing");
                        mqttHelper.messagePublish("tgn/esp_3/neopixel/color","0.0.0.255");
                        Toast.makeText(getApplicationContext(), "Off", Toast.LENGTH_LONG).show();
                    }
                }
        );
        colA.setOnClickListener(
                new Button.OnClickListener(){
                    public void onClick(View v){
                        mqttHelper.messagePublish("tgn/esp_3/neopixel/setneo","nothing");
                        mqttHelper.messagePublish("tgn/esp_3/neopixel/color","255.0.0.255");
                        Toast.makeText(getApplicationContext(), "Red", Toast.LENGTH_LONG).show();
                    }
                }
        );
        colB.setOnClickListener(
                new Button.OnClickListener(){
                    public void onClick(View v){
                        mqttHelper.messagePublish("tgn/esp_3/neopixel/setneo","nothing");
                        mqttHelper.messagePublish("tgn/esp_3/neopixel/color","0.255.0.255");
                        Toast.makeText(getApplicationContext(), "Green", Toast.LENGTH_LONG).show();
                    }
                }
        );
        colC.setOnClickListener(
                new Button.OnClickListener(){
                    public void onClick(View v){
                        mqttHelper.messagePublish("tgn/esp_3/neopixel/setneo","nothing");
                        mqttHelper.messagePublish("tgn/esp_3/neopixel/color","0.0.255.255");
                        Toast.makeText(getApplicationContext(), "Blue", Toast.LENGTH_LONG).show();
                    }
                }
        );
        sb1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }
            @SuppressLint("SetTextI18n")
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                sbValue = sb1.getProgress();
                textbar.setText(Integer.toString(sbValue));
                mqttHelper.messagePublish("tgn/esp_3/neopixel/brightness",Integer.toString(sbValue));
            }
        });
        mqttHelper.setCallback(new MqttCallbackExtended() {
            @Override
            public void connectComplete(boolean b, String s) {
            }
            @Override
            public void connectionLost(Throwable throwable) {
            }
            @SuppressLint("SetTextI18n")
            @Override
            public void messageArrived(String topic, MqttMessage mqttMessage) {
                if (topic.equals("tgn/esp_3/neopixel/brightness")) {
                    sbValue = Integer.parseInt(mqttMessage.toString());
                    sb1.setProgress(sbValue);
                    textbar.setText(Integer.toString(sbValue));
                }
                if (topic.equals("tgn/esp_3/neopixel/color")) {
                    String c_col = mqttMessage.toString();
                    colortext.setText(c_col);
                }
                if (topic.equals("tgn/esp_3/neopixel/color_cach")) {
                    mDefaultColor = Integer.parseInt(mqttMessage.toString());
                }
                if (topic.equals("tgn/esp_3/connection/ip")) {
                    String nip = mqttMessage.toString();
                    nodeip.setText(nip);
                }
            }
            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {
            }
        });
    }
}
