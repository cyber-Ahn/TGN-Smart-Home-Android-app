package mqtt.ahn.cyber.tgnsmarthomeandroid;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttMessage;

public class NeoPixel2Activity extends Activity {
    public String out_data;
    public Button but_send;
    public EditText etledNumber;
    public EditText etcolor;
    public EditText etbrightness;
    public TextView nodeip;
    public TextView textView45;
    public int sendid = 777;
    public String serverUri = "tcp://192.168.0.0:1883";
    public String clientId = "AndroidClient";
    public String col_set = "1";
    MqttHelper mqttHelper;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_neopixel2);
        but_send = findViewById(R.id.bu_send);
        etledNumber = findViewById(R.id.text_lednum);
        etcolor = findViewById(R.id.text_color);
        etbrightness = findViewById(R.id.text_brightness);
        nodeip = findViewById(R.id.textView46);
        textView45 = findViewById(R.id.textView45);
        SharedPreferences mySPR = getSharedPreferences("MySPFILE",0);
        serverUri = mySPR.getString("0096","tcp://192.168.0.1:1883");
        col_set = mySPR.getString("color","0");
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        startMqtt();
    }

    @Override
    protected void onPause() {
        super.onPause();
        Toast.makeText(getApplicationContext(), "Stop Mqtt reciver", Toast.LENGTH_LONG).show();
        finish();
        System.exit(0);
    }

    private void startMqtt() {
        mqttHelper = new MqttHelper(getApplicationContext(), serverUri, clientId);
        final Button button1 = this.findViewById(R.id.backbuttonb);
        if(col_set.equals("1"))
        {
            textView45.setTextColor(getResources().getColor(R.color.text2));
            nodeip.setTextColor(getResources().getColor(R.color.text2));
            but_send.setBackgroundColor(getResources().getColor(R.color.btn2));
            button1.setBackgroundColor(getResources().getColor(R.color.btn2));
        }
        button1.setOnClickListener(
                new Button.OnClickListener() {
                    public void onClick(View v) {
                        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                        Intent activityintent = new Intent(NeoPixel2Activity.this, NeoPixelActivity.class);
                        startActivityForResult(activityintent, sendid);
                    }
                }
        );
        but_send.setOnClickListener(
                new Button.OnClickListener(){
                    public void onClick(View v){
                        out_data = etledNumber.getText().toString() + "_" + etcolor.getText().toString() + "_" + etbrightness.getText().toString();
                        mqttHelper.messagePublish("tgn/esp_3/neopixel/setneo",out_data);
                        Toast.makeText(getApplicationContext(), "Set Led", Toast.LENGTH_LONG).show();
                    }
                }
        );
        mqttHelper.setCallback(new MqttCallbackExtended() {
            @Override
            public void connectComplete(boolean b, String s) {
            }
            @Override
            public void connectionLost(Throwable throwable) {
            }
            @SuppressLint("SetTextI18n")
            @Override
            public void messageArrived(String topic, MqttMessage mqttMessage) {
                if (topic.equals("tgn/esp_3/connection/ip")) {
                    String nip = mqttMessage.toString();
                    nodeip.setText(nip);
                }
            }
            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {
            }
        });
    }

}
