package mqtt.ahn.cyber.tgnsmarthomeandroid;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttMessage;

public class airActivity extends Activity {
    public Button but_set;
    public Button but_fan;
    public Button but_cool;
    public Button but_dry;
    public Button but_power;
    public Button but_down;
    public Button but_up;
    public EditText text_delay;
    public EditText text_sol_temp;
    public EditText text_sol_hum;
    public TextView air_stat;
    public TextView air_t;
    public int sendid = 777;
    public String serverUri = "tcp://192.168.0.0:1883";
    public String clientId = "AndroidClient";
    public String col_set = "1";
    public String out_send;
    MqttHelper mqttHelper;

    @SuppressLint({"SetTextI18n", "MissingInflatedId"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_air);
        but_set = findViewById(R.id.bu_set);
        but_fan = findViewById(R.id.bu_fan);
        but_cool = findViewById(R.id.bu_cool);
        but_dry = findViewById(R.id.bu_dry);
        but_power = findViewById(R.id.bu_power);
        but_down = findViewById(R.id.bu_down);
        but_up = findViewById(R.id.bu_up);
        text_delay = findViewById(R.id.text_delay);
        text_sol_temp = findViewById(R.id.text_sol_temp);
        text_sol_hum = findViewById(R.id.text_sol_hum);
        air_stat = findViewById(R.id.air_stat);
        air_t = findViewById(R.id.air_t);
        SharedPreferences mySPR = getSharedPreferences("MySPFILE",0);
        serverUri = mySPR.getString("0096","tcp://192.168.0.1:1883");
        col_set = mySPR.getString("color","0");
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        startMqtt();
    }

    private void startMqtt() {
        mqttHelper = new MqttHelper(getApplicationContext(), serverUri, clientId);
        final Button button1 = this.findViewById(R.id.backbuttonb);
        if(col_set.equals("1"))
        {
            air_t.setTextColor(getResources().getColor(R.color.text2));
            air_stat.setTextColor(getResources().getColor(R.color.text2));
            but_set.setBackgroundColor(getResources().getColor(R.color.btn2));
            but_fan.setBackgroundColor(getResources().getColor(R.color.btn2));
            but_cool.setBackgroundColor(getResources().getColor(R.color.btn2));
            but_dry.setBackgroundColor(getResources().getColor(R.color.btn2));
            but_power.setBackgroundColor(getResources().getColor(R.color.btn2));
            button1.setBackgroundColor(getResources().getColor(R.color.btn2));
        }
        button1.setOnClickListener(
                v -> {
                    getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    Intent activityintent = new Intent(airActivity.this, MainActivity.class);
                    startActivityForResult(activityintent, sendid);
                }
        );
        but_set.setOnClickListener(
                v -> {
                    mqttHelper.messagePublish("tgn/air_conditioner/delay",text_delay.getText().toString());
                    mqttHelper.messagePublish("tgn/air_conditioner/sol_temp",text_sol_temp.getText().toString());
                    mqttHelper.messagePublish("tgn/air_conditioner/sol_hum",text_sol_hum.getText().toString());
                    Toast.makeText(getApplicationContext(), "Set", Toast.LENGTH_LONG).show();
                }
        );
        but_fan.setOnClickListener(
                v -> {
                    out_send = "{\"Protocol\":\"NEC\",\"Bits\":32,\"Data\":\"0x8E710EF\",\"DataLSB\":\"0x10E708F7\",\"Repeat\":20,\"Channel\":1}";
                    mqttHelper.messagePublish("cmnd/tasmota_E3DAF4/IRSend",out_send);
                }
        );
        but_cool.setOnClickListener(
                v -> {
                    out_send = "{\"Protocol\":\"NEC\",\"Bits\":32,\"Data\":\"0x8E728D7\",\"DataLSB\":\"0x10E714EB\",\"Repeat\":20,\"Channel\":1}";
                    mqttHelper.messagePublish("cmnd/tasmota_E3DAF4/IRSend",out_send);
                }
        );
        but_dry.setOnClickListener(
                v -> {
                    out_send = "{\"Protocol\":\"NEC\",\"Bits\":32,\"Data\":\"0x8E730CF\",\"DataLSB\":\"0x10E70CF3\",\"Repeat\":20,\"Channel\":1}";
                    mqttHelper.messagePublish("cmnd/tasmota_E3DAF4/IRSend",out_send);
                }
        );
        but_power.setOnClickListener(
                v -> {
                    out_send = "{\"Protocol\":\"NEC\",\"Bits\":32,\"Data\":\"0x8E700FF\",\"DataLSB\":\"0x10E700FF\",\"Repeat\":20,\"Channel\":1}";
                    mqttHelper.messagePublish("cmnd/tasmota_E3DAF4/IRSend",out_send);
                }
        );
        but_down.setOnClickListener(
                v -> {
                    out_send = "{\"Protocol\":\"NEC\",\"Bits\":32,\"Data\":\"0x8E7B04F\",\"DataLSB\":\"0x10E70DF2\",\"Repeat\":20,\"Channel\":1}";
                    mqttHelper.messagePublish("cmnd/tasmota_E3DAF4/IRSend",out_send);
                }
        );
        but_up.setOnClickListener(
                v -> {
                    out_send = "{\"Protocol\":\"NEC\",\"Bits\":32,\"Data\":\"0x8E7A857\",\"DataLSB\":\"0x10E715EA\",\"Repeat\":20,\"Channel\":1}";
                    mqttHelper.messagePublish("cmnd/tasmota_E3DAF4/IRSend",out_send);
                }
        );
        mqttHelper.setCallback(new MqttCallbackExtended() {
            @Override
            public void connectComplete(boolean b, String s) {
            }
            @Override
            public void connectionLost(Throwable throwable) {
            }
            @SuppressLint("SetTextI18n")
            @Override
            public void messageArrived(String topic, MqttMessage mqttMessage) {
                if (topic.equals("tgn/air_conditioner/stat")) {
                    String nip = mqttMessage.toString();
                    if(nip.equals("0")){
                        nip = "off";
                    }
                    if(nip.equals("1")){
                        nip = "Fan";
                    }
                    if(nip.equals("2")){
                        nip = "Cool";
                    }
                    if(nip.equals("3")){
                        nip = "Dry";
                    }
                    air_stat.setText(nip);
                }
                if (topic.equals("tgn/air_conditioner/delay")) {
                    text_delay.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/air_conditioner/sol_temp")) {
                    text_sol_temp.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/air_conditioner/sol_hum")) {
                    text_sol_hum.setText(mqttMessage.toString());
                }
            }
            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {
            }
        });
    }

}
