package mqtt.ahn.cyber.tgnsmarthomeandroid;


import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

public class MqttMsgActivity extends Activity {

    public String serverUri = "tcp://192.168.0.0:1883";
    public String clientId = "AndroidClient";
    public String incomdata = "xxxx";
    MqttHelper mqttHelper;
    public EditText mqttmsg;
    public String ettext;
    public int sendid = 888;
    public String col_set = "1";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mqttmsg);
        mqttmsg = findViewById(R.id.mqttmsg);
        final Bundle intentinput = getIntent().getExtras();
        if(intentinput != null){
            incomdata = intentinput.getString("brockerIP");
            if (incomdata == null){
                incomdata = "xxxx";
            }
            if(!incomdata.equals("xxxx")){
                SharedPreferences mySPR = getSharedPreferences("MySPFILE",0);
                SharedPreferences.Editor editor = mySPR.edit();
                editor.putString("0096", incomdata);
                editor.apply();
            }
        }
        SharedPreferences mySPR = getSharedPreferences("MySPFILE",0);
        serverUri = mySPR.getString("0096","tcp://192.168.0.1:1883");
        col_set = mySPR.getString("color","0");
        startMqtt();
    }

    private void startMqtt() {
        mqttHelper = new MqttHelper(getApplicationContext(), serverUri, clientId);
        final Button button1 = this.findViewById(R.id.backbutton);
        final Button button2 = this.findViewById(R.id.btSend);
        if(col_set.equals("1"))
        {
            button2.setBackgroundColor(getResources().getColor(R.color.btn2));
            button1.setBackgroundColor(getResources().getColor(R.color.btn2));
        }
        button1.setOnClickListener(
                new Button.OnClickListener(){
                    public void onClick(View v){
                        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                        Intent activityintent = new Intent(MqttMsgActivity.this, MainActivity.class);
                        startActivityForResult(activityintent, sendid);
                    }
                }
        );
        button2.setOnClickListener(
                new Button.OnClickListener(){
                    public void onClick(View v){
                        ettext = mqttmsg.getText().toString();
                        mqttHelper.messagePublish("tgn/mqtt-msg",ettext);
                    }
                }
        );
    }
}
