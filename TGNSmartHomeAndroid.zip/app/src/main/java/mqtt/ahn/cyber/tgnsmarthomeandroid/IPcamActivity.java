package mqtt.ahn.cyber.tgnsmarthomeandroid;

        import android.annotation.SuppressLint;
        import android.app.Activity;
        import android.content.Intent;
        import android.content.SharedPreferences;
        import android.net.Uri;
        import android.os.Bundle;
        import android.view.View;
        import android.view.WindowManager;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.TextView;
        import android.widget.Toast;
        import android.widget.ImageView;

public class IPcamActivity extends Activity {

    public String serverUri = "tcp://192.168.0.0:1883";
    public String clientId = "AndroidClient";
    public String out_data;
    public String col_set = "1";
    TextView textView70;
    TextView textView71;
    MqttHelper mqttHelper;
    public int sendid = 555;
    Button capture;
    Button stream;
    Button record;
    Button cam;
    public EditText recTime;
    private ImageView imageView;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ipcam);
        capture = findViewById(R.id.bt_capture);
        stream = findViewById(R.id.bt_stream);
        record = findViewById(R.id.bt_rec);
        recTime = findViewById(R.id.text_rec_time);
        cam = findViewById(R.id.bt_cam);
        textView70 = findViewById(R.id.textView70);
        textView71 = findViewById(R.id.textView71);
        this.imageView = this.findViewById(R.id.imageView);
        SharedPreferences mySPR = getSharedPreferences("MySPFILE",0);
        serverUri = mySPR.getString("0096","tcp://192.168.0.1:1883");
        col_set = mySPR.getString("color","0");
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        startMqtt();
    }

    @Override
    protected void onPause() {
        super.onPause();
        Toast.makeText(getApplicationContext(), "Stop Mqtt reciver", Toast.LENGTH_LONG).show();
        finish();
        System.exit(0);
    }

    private void startMqtt() {
        mqttHelper = new MqttHelper(getApplicationContext(), serverUri, clientId);
        final Button button1 = this.findViewById(R.id.backbuttonb);
        if(col_set.equals("1"))
        {
            textView70.setTextColor(getResources().getColor(R.color.text2));
            textView71.setTextColor(getResources().getColor(R.color.text2));
            capture.setBackgroundColor(getResources().getColor(R.color.btn2));
            stream.setBackgroundColor(getResources().getColor(R.color.btn2));
            record.setBackgroundColor(getResources().getColor(R.color.btn2));
            cam.setBackgroundColor(getResources().getColor(R.color.btn2));
            button1.setBackgroundColor(getResources().getColor(R.color.btn2));
        }
        button1.setOnClickListener(
                new Button.OnClickListener() {
                    public void onClick(View v) {
                        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                        Intent activityintent = new Intent(IPcamActivity.this, MainActivity.class);
                        startActivityForResult(activityintent, sendid);
                    }
                }
        );
        capture.setOnClickListener(
                new Button.OnClickListener() {
                    public void onClick(View v) {
                        mqttHelper.messagePublish("tgn/esp_32_cam/capture", "1");
                        Toast.makeText(getApplicationContext(), "Capture", Toast.LENGTH_LONG).show();
                    }
                }
        );
        stream.setOnClickListener(
                new Button.OnClickListener() {
                    public void onClick(View v) {
                        mqttHelper.messagePublish("tgn/esp_32_cam/stream", "1");
                        Toast.makeText(getApplicationContext(), "Start Stream", Toast.LENGTH_LONG).show();
                    }
                }
        );
        record.setOnClickListener(
                new Button.OnClickListener() {
                    public void onClick(View v) {
                        out_data = recTime.getText().toString();
                        mqttHelper.messagePublish("tgn/esp_32_cam/record", out_data);
                        Toast.makeText(getApplicationContext(), "Record", Toast.LENGTH_LONG).show();
                    }
                }
        );
        cam.setOnClickListener(
                new Button.OnClickListener() {
                    public void onClick(View v) {
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.cam_url)));
                        startActivity(intent);
                        Toast.makeText(getApplicationContext(), "Web Interface", Toast.LENGTH_LONG).show();
                    }
                }
        );
        this.imageView.setImageResource(R.drawable.bild1);
    }
}
