package mqtt.ahn.cyber.tgnsmarthomeandroid;

import android.annotation.SuppressLint;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.format.Formatter;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.jaredrummler.android.device.DeviceName;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttMessage;

public class MainActivity extends AppCompatActivity {

    private static final String CHANNEL_ID = "default_channel_id";
    public String serverUri = "tcp://192.168.0.0:1883";
    public String clientId = "AndroidClient";
    public String ba1 = "offline";
    public String ba2 = "offline";
    public String ba3 = "offline";
    public String ba4 = "offline";
    public String ba5 = "offline";
    public String ba6 = "offline";
    public String incomdata = "xxxx";
    public String incomdatab;
    public String message;
    public String cach0;
    public String cach1 = "Off";
    public String cach2 = "no Rain";
    public String cach4;
    public String cach5 = "offline";
    public int sendid = 555;
    public int cach_analog = 0;
    public String col_set = "1";
    MqttHelper mqttHelper;
    TextView versionReceived;
    TextView ipReceived;
    TextView WtempReceived;
    TextView WhumReceived;
    TextView WcloudReceived;
    TextView clientReceived;
    TextView blockReceived;
    TextView querReceived;
    TextView mcpReceived;
    TextView lcdReceived;
    TextView rtcReceived;
    TextView romReceived;
    TextView b1namReceived;
    TextView b1statReceived;
    TextView b2namReceived;
    TextView b2statReceived;
    TextView b3namReceived;
    TextView b3statReceived;
    TextView b4namReceived;
    TextView b4statReceived;
    TextView b5namReceived;
    TextView b5statReceived;
    TextView b6namReceived;
    TextView b6statReceived;
    TextView eipReceived;
    TextView eipReceivedSon;
    TextView eipReceivedCam;
    TextView etempReceived;
    TextView ehumReceived;
    TextView elightReceived;
    TextView e2lightReceived;
    TextView e2pirReceived;
    TextView e2ipReceived;
    TextView e2tempReceived;
    TextView e3ipReceived;
    TextView e3colorReceived;
    TextView e3brReceived;
    TextView timeRecived;
    TextView autoRecived;
    TextView botRecived;
    TextView textView5;
    TextView hardwareTx;
    TextView button_stateTx;
    TextView mcip;
    TextView mcping;
    TextView mcplayer;
    TextView mcstatus;
    TextView mcipV6;
    private ImageView weatherImage;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        versionReceived = findViewById(R.id.versionReceived);
        ipReceived = findViewById(R.id.ipReceived);
        WtempReceived = findViewById(R.id.WtempReceived);
        WhumReceived = findViewById(R.id.WhumReceived);
        WcloudReceived = findViewById(R.id.WcloudReceived);
        clientReceived = findViewById(R.id.clientReceived);
        blockReceived = findViewById(R.id.blockReceived);
        querReceived = findViewById(R.id.querReceived);
        mcpReceived = findViewById(R.id.mcpReceived);
        lcdReceived = findViewById(R.id.lcdReceived);
        rtcReceived = findViewById(R.id.rtcReceived);
        romReceived = findViewById(R.id.romReceived);
        b1namReceived = findViewById(R.id.b1namReceived);
        b1statReceived = findViewById(R.id.b1statReceived);
        b2namReceived = findViewById(R.id.b2namReceived);
        b2statReceived = findViewById(R.id.b2statReceived);
        b3namReceived = findViewById(R.id.b3namReceived);
        b3statReceived = findViewById(R.id.b3statReceived);
        b4statReceived = findViewById(R.id.b4statReceived);
        b4namReceived = findViewById(R.id.b4namReceived);
        b5statReceived = findViewById(R.id.b5statReceived);
        b5namReceived = findViewById(R.id.b5namReceived);
        b6statReceived = findViewById(R.id.b6statReceived);
        b6namReceived = findViewById(R.id.b6namReceived);
        eipReceived = findViewById(R.id.eipReceived);
        eipReceivedSon = findViewById(R.id.ipReceivedSon);
        eipReceivedCam = findViewById(R.id.ipReceivedCam);
        etempReceived = findViewById(R.id.etempReceived);
        ehumReceived = findViewById(R.id.ehumReceived);
        elightReceived = findViewById(R.id.elightReceived);
        e2lightReceived = findViewById(R.id.e2lightReceived);
        e2pirReceived = findViewById(R.id.e2pirReceived);
        e2ipReceived = findViewById(R.id.e2ipReceived);
        e2tempReceived = findViewById(R.id.e2tempReceived);
        e3ipReceived = findViewById(R.id.e3ipReceived);
        e3colorReceived = findViewById(R.id.textView59);
        e3brReceived = findViewById(R.id.textView61);
        timeRecived = findViewById(R.id.RecivedTime);
        autoRecived = findViewById(R.id.recived_auto);
        botRecived = findViewById(R.id.botRecived);
        weatherImage = findViewById(R.id.weather_image);
        textView5 = findViewById(R.id.textView5);
        hardwareTx = findViewById(R.id.hardwareTx);
        button_stateTx = findViewById(R.id.button_stateTx);
        mcping = findViewById(R.id.mcping);
        mcip = findViewById(R.id.mcip);
        mcplayer = findViewById(R.id.mcplayer);
        mcstatus = findViewById(R.id.mcstatus);
        mcipV6 = findViewById(R.id.mcipV6);
        final Bundle intentinput = getIntent().getExtras();
        if(intentinput != null){
            incomdata = intentinput.getString("brockerIP");
            incomdatab = intentinput.getString("theme");
            if (incomdata == null){
                incomdata = "xxxx";
            }
            if(!incomdata.equals("xxxx")){
                SharedPreferences mySPR = getSharedPreferences("MySPFILE",0);
                SharedPreferences.Editor editor = mySPR.edit();
                editor.putString("0096", incomdata);
                editor.putString("color", incomdatab);
                editor.apply();
            }
        }
        SharedPreferences mySPR = getSharedPreferences("MySPFILE",0);
        serverUri = mySPR.getString("0096","tcp://192.168.0.1:1883");
        col_set = mySPR.getString("color","0");
        startMqtt();
    }

    private void createNotificationChannel() {
        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = getString(R.string.channel_name);
            String description = getString(R.string.channel_description);
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            assert notificationManager != null;
            notificationManager.createNotificationChannel(channel);
        }
    }
    private void startMqtt() {
        mqttHelper = new MqttHelper(getApplicationContext(), serverUri, clientId);
        final Button button1 = this.findViewById(R.id.btnConnect);
        final Button button2 = this.findViewById(R.id.button2);
        final Button button3 = this.findViewById(R.id.button3);
        final Button button4 = this.findViewById(R.id.button4);
        final Button button5 = this.findViewById(R.id.button5);
        final Button button6 = this.findViewById(R.id.button6);
        final Button buttonSD = this.findViewById(R.id.buttonSD);
        final Button buttonRB = this.findViewById(R.id.buttonRB);
        final Button buttonSM = this.findViewById(R.id.mqtt_msg);
        final Button buttonRTC = this.findViewById(R.id.bt_rtc);
        if(col_set.equals("1"))
        {
            versionReceived.setTextColor(getResources().getColor(R.color.text2));
            ipReceived.setTextColor(getResources().getColor(R.color.text2));
            WtempReceived.setTextColor(getResources().getColor(R.color.text2));
            WhumReceived.setTextColor(getResources().getColor(R.color.text2));
            WcloudReceived.setTextColor(getResources().getColor(R.color.text2));
            clientReceived.setTextColor(getResources().getColor(R.color.text2));
            blockReceived.setTextColor(getResources().getColor(R.color.text2));
            querReceived.setTextColor(getResources().getColor(R.color.text2));
            mcpReceived.setTextColor(getResources().getColor(R.color.text2));
            lcdReceived.setTextColor(getResources().getColor(R.color.text2));
            rtcReceived.setTextColor(getResources().getColor(R.color.text2));
            romReceived.setTextColor(getResources().getColor(R.color.text2));
            b1namReceived.setTextColor(getResources().getColor(R.color.text2));
            b1statReceived.setTextColor(getResources().getColor(R.color.text2));
            b2namReceived.setTextColor(getResources().getColor(R.color.text2));
            b2statReceived.setTextColor(getResources().getColor(R.color.text2));
            b3namReceived.setTextColor(getResources().getColor(R.color.text2));
            b3statReceived.setTextColor(getResources().getColor(R.color.text2));
            b4namReceived.setTextColor(getResources().getColor(R.color.text2));
            b4statReceived.setTextColor(getResources().getColor(R.color.text2));
            b5namReceived.setTextColor(getResources().getColor(R.color.text2));
            b5statReceived.setTextColor(getResources().getColor(R.color.text2));
            b6namReceived.setTextColor(getResources().getColor(R.color.text2));
            b6statReceived.setTextColor(getResources().getColor(R.color.text2));
            eipReceived.setTextColor(getResources().getColor(R.color.text2));
            eipReceivedSon.setTextColor(getResources().getColor(R.color.text2));
            eipReceivedCam.setTextColor(getResources().getColor(R.color.text2));
            etempReceived.setTextColor(getResources().getColor(R.color.text2));
            ehumReceived.setTextColor(getResources().getColor(R.color.text2));
            elightReceived.setTextColor(getResources().getColor(R.color.text2));
            e2lightReceived.setTextColor(getResources().getColor(R.color.text2));
            e2pirReceived.setTextColor(getResources().getColor(R.color.text2));
            e2ipReceived.setTextColor(getResources().getColor(R.color.text2));
            e2tempReceived.setTextColor(getResources().getColor(R.color.text2));
            e3ipReceived.setTextColor(getResources().getColor(R.color.text2));
            e3colorReceived.setTextColor(getResources().getColor(R.color.text2));
            e3brReceived.setTextColor(getResources().getColor(R.color.text2));
            timeRecived.setTextColor(getResources().getColor(R.color.text2));
            autoRecived.setTextColor(getResources().getColor(R.color.text2));
            botRecived.setTextColor(getResources().getColor(R.color.text2));
            textView5.setTextColor(getResources().getColor(R.color.text2));
            mcping.setTextColor(getResources().getColor(R.color.text2));
            mcip.setTextColor(getResources().getColor(R.color.text2));
            mcplayer.setTextColor(getResources().getColor(R.color.text2));
            mcstatus.setTextColor(getResources().getColor(R.color.text2));
            mcipV6.setTextColor(getResources().getColor(R.color.text2));
            hardwareTx.setTextColor(getResources().getColor(R.color.text2));
            button_stateTx.setTextColor(getResources().getColor(R.color.text2));
            button1.setBackgroundColor(getResources().getColor(R.color.btn2));
            button2.setBackgroundColor(getResources().getColor(R.color.btn2));
            button3.setBackgroundColor(getResources().getColor(R.color.btn2));
            button4.setBackgroundColor(getResources().getColor(R.color.btn2));
            button5.setBackgroundColor(getResources().getColor(R.color.btn2));
            button6.setBackgroundColor(getResources().getColor(R.color.btn2));
            buttonSD.setBackgroundColor(getResources().getColor(R.color.btn2));
            buttonRB.setBackgroundColor(getResources().getColor(R.color.btn2));
            buttonSM.setBackgroundColor(getResources().getColor(R.color.btn2));
            buttonRTC.setBackgroundColor(getResources().getColor(R.color.btn2));
        }
        buttonRTC.setOnClickListener(
                new Button.OnClickListener(){
                    public void onClick(View v){
                        mqttHelper.messagePublish("tgn/system/clock","1");
                        Toast.makeText(getApplicationContext(), "Set RTC", Toast.LENGTH_LONG).show();
                    }
                }
        );
        buttonSM.setOnClickListener(
                new Button.OnClickListener(){
                    public void onClick(View v){
                        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                        Intent activityintent = new Intent(MainActivity.this, MqttMsgActivity.class);
                        startActivityForResult(activityintent, sendid);
                        Toast.makeText(getApplicationContext(), "Send MSG", Toast.LENGTH_LONG).show();
                    }
                }
        );
        button1.setOnClickListener(
                new Button.OnClickListener(){
                    public void onClick(View v){
                        if (ba1.equals("On")) {
                            mqttHelper.messagePublish("tgn/buttons/status/1","0");
                        }
                        else{
                            mqttHelper.messagePublish("tgn/buttons/status/1","1");
                        }
                        Toast.makeText(getApplicationContext(), "BTN 1", Toast.LENGTH_LONG).show();
                    }
                }
        );
        button2.setOnClickListener(
                new Button.OnClickListener(){
                    public void onClick(View v){
                        if (ba2.equals("On")) {
                            mqttHelper.messagePublish("tgn/buttons/status/2","0");
                        }
                        else{
                            mqttHelper.messagePublish("tgn/buttons/status/2","1");
                        }
                        Toast.makeText(getApplicationContext(), "BTN 2", Toast.LENGTH_LONG).show();
                    }
                }
        );
        button3.setOnClickListener(
                new Button.OnClickListener(){
                    public void onClick(View v){
                        if (ba3.equals("On")) {
                            mqttHelper.messagePublish("tgn/buttons/status/3","0");
                        }
                        else{
                            mqttHelper.messagePublish("tgn/buttons/status/3","1");
                        }
                        Toast.makeText(getApplicationContext(), "BTN 3", Toast.LENGTH_LONG).show();
                    }
                }
        );
        button4.setOnClickListener(
                new Button.OnClickListener(){
                    public void onClick(View v){
                        if (ba4.equals("On")) {
                            mqttHelper.messagePublish("tgn/buttons/status/4","0");
                        }
                        else{
                            mqttHelper.messagePublish("tgn/buttons/status/4","1");
                        }
                        Toast.makeText(getApplicationContext(), "BTN 4", Toast.LENGTH_LONG).show();
                    }
                }
        );
        button5.setOnClickListener(
                new Button.OnClickListener(){
                    public void onClick(View v){
                        if (ba5.equals("On")) {
                            mqttHelper.messagePublish("tgn/buttons/status/5","0");
                        }
                        else{
                            mqttHelper.messagePublish("tgn/buttons/status/5","1");
                        }
                        Toast.makeText(getApplicationContext(), "BTN 5", Toast.LENGTH_LONG).show();
                    }
                }
        );
        button6.setOnClickListener(
                new Button.OnClickListener(){
                    public void onClick(View v){
                        if (ba6.equals("On")) {
                            mqttHelper.messagePublish("tgn/buttons/status/6","0");
                        }
                        else{
                            mqttHelper.messagePublish("tgn/buttons/status/6","1");
                        }
                        Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();
                    }
                }
        );
        buttonSD.setOnClickListener(
                new Button.OnClickListener(){
                    public void onClick(View v){
                        mqttHelper.messagePublish("tgn/system/shutdown","1");
                        Toast.makeText(getApplicationContext(), "Shutdown", Toast.LENGTH_LONG).show();
                    }
                }
        );
        buttonRB.setOnClickListener(
                new Button.OnClickListener(){
                    public void onClick(View v){
                        mqttHelper.messagePublish("tgn/bot/shutdown","1");
                        mqttHelper.messagePublish("tgn/bot/status","offline");
                        Toast.makeText(getApplicationContext(), "Bot Shutdown", Toast.LENGTH_LONG).show();
                    }
                }
        );
        mqttHelper.setCallback(new MqttCallbackExtended() {
            @Override
            public void connectComplete(boolean b, String s) {
            }
            @Override
            public void connectionLost(Throwable throwable) {
            }
            @SuppressLint("SetTextI18n")
            @Override
            public void messageArrived(String topic, MqttMessage mqttMessage) {

                final String ontext = "On";
                final String offtext = "Off";
                if (topic.equals("tgn/version")){
                    versionReceived.setText("TGN Smart Home "+mqttMessage.toString());
                }
                if (topic.equals("tgn/system/automatic")){
                    if (mqttMessage.toString().equals("1")){
                        autoRecived.setText("Automatic ON");
                        if(!cach1.equals("On")){
                            message = "Automatic on";
                            cach1 = "On";
                        }
                    }
                    else {
                        autoRecived.setText("Automatic OFF");
                        if(!cach1.equals("Off")){
                            message = "Automatic off";
                            cach1 = "Off";
                        }
                    }
                }
                if (topic.equals("tgn/system/time")){
                    timeRecived.setText("System Time:  "+mqttMessage.toString());
                }
                if (topic.equals("tgn/ip")){
                    ipReceived.setText("Main IP: "+mqttMessage.toString());
                    String deviceName = DeviceName.getDeviceName();
                    WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
                    assert wifiManager != null;
                    String ipAddress = Formatter.formatIpAddress(wifiManager.getConnectionInfo().getIpAddress());
                    String release = Build.VERSION.RELEASE;
                    mqttHelper.messagePublish("tgn/android/ip",ipAddress);
                    mqttHelper.messagePublish("tgn/android/name",deviceName);
                    mqttHelper.messagePublish("tgn/android/version",release);
                }
                if (topic.equals("tgn/weather/icon")){
                    String data = mqttMessage.toString();
                    if (data.equals("200") || data.equals("211") || data.equals("212") || data.equals("221") || data.equals("905") || data.equals("960") || data.equals("961")){
                        weatherImage.setImageResource(R.drawable.thunderstorms);
                    }
                    if (data.equals("201") || data.equals("202") || data.equals("210")){
                        weatherImage.setImageResource(R.drawable.thundery_showers);
                    }
                    if (data.equals("230") || data.equals("231") || data.equals("232")){
                        weatherImage.setImageResource(R.drawable.cloudy_with_light_rain);
                    }
                    if (data.equals("300") || data.equals("301") || data.equals("302") || data.equals("310") || data.equals("311") || data.equals("312") || data.equals("313") || data.equals("314") || data.equals("321")){
                        weatherImage.setImageResource(R.drawable.cloudy_with_heavy_hail);
                    }
                    if (data.equals("500") || data.equals("501") || data.equals("502") || data.equals("503") || data.equals("504")){
                        weatherImage.setImageResource(R.drawable.heavy_rain_showers);
                    }
                    if (data.equals("511")){
                        weatherImage.setImageResource(R.drawable.cloudy_with_sleet);
                    }
                    if (data.equals("520") || data.equals("521") || data.equals("522") || data.equals("531")){
                        weatherImage.setImageResource(R.drawable.cloudy_with_light_hail_night);
                    }
                    if (data.equals("600") || data.equals("601") || data.equals("602")){
                        weatherImage.setImageResource(R.drawable.cloudy_with_light_snow);
                    }
                    if (data.equals("611") || data.equals("612")){
                        weatherImage.setImageResource(R.drawable.heavy_snow_showers);
                    }
                    if (data.equals("615") || data.equals("616") || data.equals("620") || data.equals("621") || data.equals("622")){
                        weatherImage.setImageResource(R.drawable.cloudy_with_sleet);
                    }
                    if (data.equals("701")){
                        weatherImage.setImageResource(R.drawable.light_rain_showers);
                    }
                    if (data.equals("711") || data.equals("741") || data.equals("721") || data.equals("761") || data.equals("762")){
                        weatherImage.setImageResource(R.drawable.mist);
                    }
                    if (data.equals("731") || data.equals("751") || data.equals("771")){
                        weatherImage.setImageResource(R.drawable.black_low_cloud);
                    }
                    if (data.equals("781") || data.equals("900") || data.equals("901") || data.equals("902") || data.equals("952") || data.equals("953") || data.equals("954") || data.equals("955") || data.equals("956") || data.equals("957") || data.equals("958") || data.equals("959") || data.equals("962")){
                        weatherImage.setImageResource(R.drawable.thundery_showers_night);
                    }
                    if (data.equals("800") || data.equals("951")){
                        weatherImage.setImageResource(R.drawable.sunny);
                    }
                    if (data.equals("801")){
                        weatherImage.setImageResource(R.drawable.sunny2);
                    }
                    if (data.equals("803") || data.equals("804") || data.equals("802")){
                        weatherImage.setImageResource(R.drawable.white_cloud);
                    }
                    if (data.equals("904")){
                        weatherImage.setImageResource(R.drawable.hazy_sun);
                    }
                    if (data.equals("903")){
                        weatherImage.setImageResource(R.drawable.light_snow_showers);
                    }
                        if (data.equals("906")){
                        weatherImage.setImageResource(R.drawable.heavy_hail_showers_night);
                    }
                }
                if (topic.equals("tgn/weather/temp")){
                    WtempReceived.setText("Temp: "+mqttMessage.toString()+"°C");
                    cach4 = mqttMessage.toString()+"°C";
                }
                if (topic.equals("tgn/weather/humidity")){
                    WhumReceived.setText("Humidity: "+mqttMessage.toString()+"%");
                }
                if (topic.equals("tgn/weather/clouds")){
                    WcloudReceived.setText("Clouds: "+mqttMessage.toString());
                }
                if (topic.equals("tgn/pihole/clients")){
                    clientReceived.setText("Clients: "+mqttMessage.toString());
                }
                if (topic.equals("tgn/pihole/adBlock")){
                    blockReceived.setText("Adblocked: "+mqttMessage.toString());
                }
                if (topic.equals("tgn/pihole/queries")){
                    querReceived.setText("Queries: "+mqttMessage.toString());
                }
                if (topic.equals("tgn/i2c/mcp")){
                    mcpReceived.setText("mcp23017: "+mqttMessage.toString());
                }
                if (topic.equals("tgn/i2c/lcd")){
                    lcdReceived.setText("LCD: "+mqttMessage.toString());
                }
                if (topic.equals("tgn/i2c/rtc")){
                    rtcReceived.setText("RTC: "+mqttMessage.toString());
                }
                if (topic.equals("tgn/i2c/eeprom")){
                    romReceived.setText("eeprom: "+mqttMessage.toString());
                }
                if (topic.equals("tgn/buttons/name/1")){
                    b1namReceived.setText(mqttMessage.toString()+": ");
                    button1.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/buttons/status/1")){
                    if (mqttMessage.toString().equals("1")) {
                        b1statReceived.setText(ontext);
                        ba1 = ontext;
                    }
                    else {
                        b1statReceived.setText(offtext);
                        ba1 = offtext;
                    }
                }
                if (topic.equals("tgn/buttons/name/2")){
                    b2namReceived.setText(mqttMessage.toString()+": ");
                    button2.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/buttons/status/2")){
                    if (mqttMessage.toString().equals("1")) {
                        b2statReceived.setText(ontext);
                        ba2 = ontext;
                    }
                    else {
                        b2statReceived.setText(offtext);
                        ba2 = offtext;
                    }
                }
                if (topic.equals("tgn/buttons/name/3")){
                    b3namReceived.setText(mqttMessage.toString()+": ");
                   button3.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/buttons/status/3")){
                    if (mqttMessage.toString().equals("1")) {
                        b3statReceived.setText(ontext);
                        ba3 = ontext;
                    }
                    else {
                        b3statReceived.setText(offtext);
                        ba3 = offtext;
                    }
                }
                if (topic.equals("tgn/buttons/name/4")){
                    b4namReceived.setText(mqttMessage.toString()+": ");
                   button4.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/buttons/status/4")){
                    if (mqttMessage.toString().equals("1")) {
                        b4statReceived.setText(ontext);
                        ba4 = ontext;
                    }
                    else {
                        b4statReceived.setText(offtext);
                        ba4 = offtext;
                    }
                }
                if (topic.equals("tgn/buttons/name/5")){
                    b5namReceived.setText(mqttMessage.toString()+": ");
                    button5.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/buttons/status/5")){
                    if (mqttMessage.toString().equals("1")) {
                        b5statReceived.setText(ontext);
                        ba5 = ontext;
                    }
                    else {
                        b5statReceived.setText(offtext);
                        ba5 = offtext;
                    }
                }
                if (topic.equals("tgn/buttons/name/6")){
                    b6namReceived.setText(mqttMessage.toString()+": ");
                    button6.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/buttons/status/6")){
                    if (mqttMessage.toString().equals("1")) {
                        b6statReceived.setText(ontext);
                        ba6 = ontext;
                    }
                    else {
                        b6statReceived.setText(offtext);
                        ba6 = offtext;
                    }
                }
                if (topic.equals("tgn/esp_1/connection/ip")){
                    eipReceived.setText("ESP NodeMCU 1 IP: "+mqttMessage.toString());
                }
                if (topic.equals("tgn/sonoff_1/connection/ip")){
                    eipReceivedSon.setText("Sonoff IP: "+mqttMessage.toString());
                }
                if (topic.equals("tgn/esp_32_cam/connection/ip")){
                    eipReceivedCam.setText("ESP32 Cam IP: "+mqttMessage.toString());
                }
                if (topic.equals("tgn/esp_1/temp/sensor_1")){
                    etempReceived.setText("Temp: "+mqttMessage.toString()+"°C");
                }
                if (topic.equals("tgn/esp_1/temp/sensor_2")){
                    ehumReceived.setText("Humidity: "+mqttMessage.toString()+"%");
                }
                if (topic.equals("tgn/esp_1/analog/sensor_1")){
                    cach_analog = Integer.parseInt(mqttMessage.toString());
                    cach_analog = (cach_analog * 10) / 2;
                    elightReceived.setText("Light Sensor: "+cach_analog);
                }
                if (topic.equals("tgn/esp_2/analog/sensor_1")){
                    cach_analog = Integer.parseInt(mqttMessage.toString());
                    cach_analog = (cach_analog * 10) / 2;
                    e2lightReceived.setText("Light Sensor: "+cach_analog);
                }
                if (topic.equals("tgn/weather/rain")){
                    e2pirReceived.setText(mqttMessage.toString());
                    if(!cach2.equals(mqttMessage.toString())){
                        message = mqttMessage.toString();
                    }
                }
                if (topic.equals("tgn/esp_2/connection/ip")){
                    e2ipReceived.setText("ESP NodeMCU 2 IP: "+mqttMessage.toString());
                }
                if (topic.equals("tgn/esp_2/temp/sensor_1")){
                    e2tempReceived.setText("Temp: "+mqttMessage.toString()+"°C");
                }
                if (topic.equals("tgn/esp_3/connection/ip")){
                    e3ipReceived.setText("ESP NodeMCU 3 IP: "+mqttMessage.toString());
                }
                if (topic.equals("tgn/esp_3/neopixel/color")){
                    e3colorReceived.setText("Color: "+mqttMessage.toString());
                }
                if (topic.equals("tgn/esp_3/neopixel/brightness")){
                    e3brReceived.setText("Brightness: "+mqttMessage.toString());
                }
                if (topic.equals("tgn/mc_server/ip")){
                    mcip.setText("MC Server IP: "+mqttMessage.toString());
                }
                if (topic.equals("tgn/mc_server/status")){
                    mcstatus.setText("Server is: "+mqttMessage.toString());
                    if(!cach5.equals(mqttMessage.toString())){
                        cach5 = mqttMessage.toString();
                        message = "Server is:"+mqttMessage.toString();
                    }
                }
                if (topic.equals("tgn/mc_server/ping")){
                    mcping.setText("Ping: "+mqttMessage.toString());
                }
                if (topic.equals("tgn/mc_server/player")){
                    mcplayer.setText("Player: "+mqttMessage.toString());
                }
                if (topic.equals("tgn/mc_server/ipV6")){
                    mcipV6.setText("IPV6 global: "+mqttMessage.toString());
                }
                if (topic.equals("tgn/bot/status")){
                    if (mqttMessage.toString().equals("online")){
                        botRecived.setText("Discord Bot online");
                    }
                    else {
                        botRecived.setText("Discord Bot offline");
                    }
                }
                if(!message.equals(cach0)){
                    createNotificationChannel();
                    cach0 = message;
                    String channelId = "default_channel_id";
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(MainActivity.this, CHANNEL_ID)
                            .setSmallIcon(R.drawable.ic_message)
                            .setContentTitle("TGN Smart Home")
                            .setContentText(message+ " - Weather Temp:" + cach4)
                            .setPriority(NotificationCompat.PRIORITY_HIGH)
                            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                            .setVibrate(new long[]{100, 200, 300, 400, 500, 400, 300, 200, 400})
                            .setChannelId(channelId);
                    NotificationManager notificationManager = (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
                    assert notificationManager != null;
                    notificationManager.notify(0, builder.build());
                }
            }
            @Override
            public void deliveryComplete(IMqttDeliveryToken iMqttDeliveryToken) {
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            Intent activityintent = new Intent(MainActivity.this, SettingsActivity.class);
            startActivityForResult(activityintent, sendid);
        }
        if (id == R.id.debug_window) {
            Intent activityintent = new Intent(MainActivity.this, DebugsActivity.class);
            startActivityForResult(activityintent, sendid);
        }
        if (id == R.id.neopixel_window) {
            Intent activityintent = new Intent(MainActivity.this, NeoPixelActivity.class);
            startActivityForResult(activityintent, sendid);
        }
        if (id == R.id.ipcam_window) {
            Intent activityintent = new Intent(MainActivity.this, IPcamActivity.class);
            startActivityForResult(activityintent, sendid);
        }
        if (id == R.id.switch_window) {
            Intent activityintent = new Intent(MainActivity.this, switchActivity.class);
            startActivityForResult(activityintent, sendid);
        }
        if (id == R.id.exit_sys) {
            finish();
            System.exit(0);
        }
        return super.onOptionsItemSelected(item);
    }
}
