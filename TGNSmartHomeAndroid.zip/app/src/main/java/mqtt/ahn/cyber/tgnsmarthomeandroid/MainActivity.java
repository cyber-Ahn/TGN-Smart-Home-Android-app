package mqtt.ahn.cyber.tgnsmarthomeandroid;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttMessage;

public class MainActivity extends AppCompatActivity {

    public String serverUri = "tcp://192.168.0.0:1883";
    public String clientId = "AndroidClient";
    public String ba1 = "offline";
    public String ba2 = "offline";
    public String ba3 = "offline";
    public String ba4 = "offline";
    public String ba5 = "offline";
    public String ba6 = "offline";
    public String incomdata = "xxxx";
    public int sendid = 555;
    MqttHelper mqttHelper;
    TextView versionReceived;
    TextView ipReceived;
    TextView WtempReceived;
    TextView WhumReceived;
    TextView WcloudReceived;
    TextView WwindReceived;
    TextView clientReceived;
    TextView blockReceived;
    TextView querReceived;
    TextView mcpReceived;
    TextView lcdReceived;
    TextView rtcReceived;
    TextView romReceived;
    TextView b1namReceived;
    TextView b1statReceived;
    TextView b2namReceived;
    TextView b2statReceived;
    TextView b3namReceived;
    TextView b3statReceived;
    TextView b4namReceived;
    TextView b4statReceived;
    TextView b5namReceived;
    TextView b5statReceived;
    TextView b6namReceived;
    TextView b6statReceived;
    TextView eipReceived;
    TextView etempReceived;
    TextView ehumReceived;
    TextView elightReceived;
    TextView e2lightReceived;
    TextView e2pirReceived;
    TextView e2ipReceived;
    TextView e2tempReceived;
    TextView upTimeReceived;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        versionReceived = findViewById(R.id.versionReceived);
        ipReceived = findViewById(R.id.ipReceived);
        WtempReceived = findViewById(R.id.WtempReceived);
        WhumReceived = findViewById(R.id.WhumReceived);
        WcloudReceived = findViewById(R.id.WcloudReceived);
        WwindReceived = findViewById(R.id.WwindReceived);
        clientReceived = findViewById(R.id.clientReceived);
        blockReceived = findViewById(R.id.blockReceived);
        querReceived = findViewById(R.id.querReceived);
        mcpReceived = findViewById(R.id.mcpReceived);
        lcdReceived = findViewById(R.id.lcdReceived);
        rtcReceived = findViewById(R.id.rtcReceived);
        romReceived = findViewById(R.id.romReceived);
        b1namReceived = findViewById(R.id.b1namReceived);
        b1statReceived = findViewById(R.id.b1statReceived);
        b2namReceived = findViewById(R.id.b2namReceived);
        b2statReceived = findViewById(R.id.b2statReceived);
        b3namReceived = findViewById(R.id.b3namReceived);
        b3statReceived = findViewById(R.id.b3statReceived);
        b4statReceived = findViewById(R.id.b4statReceived);
        b4namReceived = findViewById(R.id.b4namReceived);
        b5statReceived = findViewById(R.id.b5statReceived);
        b5namReceived = findViewById(R.id.b5namReceived);
        b6statReceived = findViewById(R.id.b6statReceived);
        b6namReceived = findViewById(R.id.b6namReceived);
        eipReceived = findViewById(R.id.eipReceived);
        etempReceived = findViewById(R.id.etempReceived);
        ehumReceived = findViewById(R.id.ehumReceived);
        elightReceived = findViewById(R.id.elightReceived);
        e2lightReceived = findViewById(R.id.e2lightReceived);
        e2pirReceived = findViewById(R.id.e2pirReceived);
        e2ipReceived = findViewById(R.id.e2ipReceived);
        e2tempReceived = findViewById(R.id.e2tempReceived);
        upTimeReceived = findViewById(R.id.upTimeReceived);

        final Bundle intentinput = getIntent().getExtras();
        if(intentinput != null){
            incomdata = intentinput.getString("brockerIP");
            if (incomdata == null){
                incomdata = "xxxx";
            }
            if(!incomdata.equals("xxxx")){
                SharedPreferences mySPR = getSharedPreferences("MySPFILE",0);
                SharedPreferences.Editor editor = mySPR.edit();
                editor.putString("0096", incomdata);
                editor.apply();
            }
        }
        SharedPreferences mySPR = getSharedPreferences("MySPFILE",0);
        serverUri = mySPR.getString("0096","tcp://192.168.0.1:1883");
        startMqtt();
    }

    @Override
    protected void onPause() {
        super.onPause();
        Toast.makeText(getApplicationContext(), "Stop Mqtt reciver", Toast.LENGTH_LONG).show();
        finish();
        System.exit(0);
    }

    private void startMqtt() {
        mqttHelper = new MqttHelper(getApplicationContext(), serverUri, clientId);
        final Button button1 = this.findViewById(R.id.btnConnect);
        final Button button2 = this.findViewById(R.id.button2);
        final Button button3 = this.findViewById(R.id.button3);
        final Button button4 = this.findViewById(R.id.button4);
        final Button button5 = this.findViewById(R.id.button5);
        final Button button6 = this.findViewById(R.id.button6);
        final Button buttonSD = this.findViewById(R.id.buttonSD);
        final Button buttonRB = this.findViewById(R.id.buttonRB);
        final Button buttonWE = this.findViewById(R.id.buttonWE);
        final Button buttonMIC = this.findViewById(R.id.buttonMIC);
        button1.setOnClickListener(
                new Button.OnClickListener(){
                    public void onClick(View v){
                        if (ba1.equals("On")) {
                            mqttHelper.messagePublish("tgn/buttons/status/1","0");
                        }
                        else{
                            mqttHelper.messagePublish("tgn/buttons/status/1","1");
                        }
                    }
                }
        );
        button2.setOnClickListener(
                new Button.OnClickListener(){
                    public void onClick(View v){
                        if (ba2.equals("On")) {
                            mqttHelper.messagePublish("tgn/buttons/status/2","0");
                        }
                        else{
                            mqttHelper.messagePublish("tgn/buttons/status/2","1");
                        }
                    }
                }
        );
        button3.setOnClickListener(
                new Button.OnClickListener(){
                    public void onClick(View v){
                        if (ba3.equals("On")) {
                            mqttHelper.messagePublish("tgn/buttons/status/3","0");
                        }
                        else{
                            mqttHelper.messagePublish("tgn/buttons/status/3","1");
                        }
                    }
                }
        );
        button4.setOnClickListener(
                new Button.OnClickListener(){
                    public void onClick(View v){
                        if (ba4.equals("On")) {
                            mqttHelper.messagePublish("tgn/buttons/status/4","0");
                        }
                        else{
                            mqttHelper.messagePublish("tgn/buttons/status/4","1");
                        }
                    }
                }
        );
        button5.setOnClickListener(
                new Button.OnClickListener(){
                    public void onClick(View v){
                        if (ba5.equals("On")) {
                            mqttHelper.messagePublish("tgn/buttons/status/5","0");
                        }
                        else{
                            mqttHelper.messagePublish("tgn/buttons/status/5","1");
                        }
                    }
                }
        );
        button6.setOnClickListener(
                new Button.OnClickListener(){
                    public void onClick(View v){
                        if (ba6.equals("On")) {
                            mqttHelper.messagePublish("tgn/buttons/status/6","0");
                        }
                        else{
                            mqttHelper.messagePublish("tgn/buttons/status/6","1");
                        }
                    }
                }
        );
        buttonSD.setOnClickListener(
                new Button.OnClickListener(){
                    public void onClick(View v){
                        mqttHelper.messagePublish("tgn/system/shutdown","1");
                    }
                }
        );
        buttonRB.setOnClickListener(
                new Button.OnClickListener(){
                    public void onClick(View v){
                        mqttHelper.messagePublish("tgn/system/reboot","1");
                    }
                }
        );
        buttonWE.setOnClickListener(
                new Button.OnClickListener(){
                    public void onClick(View v){
                        mqttHelper.messagePublish("tgn/system/weather","1");
                    }
                }
        );
        buttonMIC.setOnClickListener(
                new Button.OnClickListener(){
                    public void onClick(View v){
                        mqttHelper.messagePublish("tgn/system/mic","1");
                    }
                }
        );
        mqttHelper.setCallback(new MqttCallbackExtended() {
            @Override
            public void connectComplete(boolean b, String s) {
            }
            @Override
            public void connectionLost(Throwable throwable) {
            }
            @SuppressLint("SetTextI18n")
            @Override
            public void messageArrived(String topic, MqttMessage mqttMessage) {
                final String ontext = "On";
                final String offtext = "Off";
                if (topic.equals("tgn/version")){
                    versionReceived.setText("TGN Smart Home "+mqttMessage.toString());
                }
                if (topic.equals("tgn/ip")){
                    ipReceived.setText(mqttMessage.toString());
                    mqttHelper.messagePublish("android/found","found");
                }
                if (topic.equals("tgn/weather/temp")){
                    WtempReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/weather/humidity")){
                    WhumReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/weather/clouds")){
                    WcloudReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/weather/wind")){
                    WwindReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/pihole/clients")){
                    clientReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/pihole/adBlock")){
                    blockReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/pihole/queries")){
                    querReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/i2c/mcp")){
                    mcpReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/i2c/lcd")){
                    lcdReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/i2c/rtc")){
                    rtcReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/i2c/eeprom")){
                    romReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/system/update")){
                    upTimeReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/buttons/name/1")){
                    b1namReceived.setText(mqttMessage.toString()+":");
                    button1.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/buttons/status/1")){
                    if (mqttMessage.toString().equals("1")) {
                        b1statReceived.setText(ontext);
                        ba1 = ontext;
                    }
                    else {
                        b1statReceived.setText(offtext);
                        ba1 = offtext;
                    }
                }
                if (topic.equals("tgn/buttons/name/2")){
                    b2namReceived.setText(mqttMessage.toString()+":");
                    button2.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/buttons/status/2")){
                    if (mqttMessage.toString().equals("1")) {
                        b2statReceived.setText(ontext);
                        ba2 = ontext;
                    }
                    else {
                        b2statReceived.setText(offtext);
                        ba2 = offtext;
                    }
                }
                if (topic.equals("tgn/buttons/name/3")){
                    b3namReceived.setText(mqttMessage.toString()+":");
                    button3.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/buttons/status/3")){
                    if (mqttMessage.toString().equals("1")) {
                        b3statReceived.setText(ontext);
                        ba3 = ontext;
                    }
                    else {
                        b3statReceived.setText(offtext);
                        ba3 = offtext;
                    }
                }
                if (topic.equals("tgn/buttons/name/4")){
                    b4namReceived.setText(mqttMessage.toString()+":");
                    button4.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/buttons/status/4")){
                    if (mqttMessage.toString().equals("1")) {
                        b4statReceived.setText(ontext);
                        ba4 = ontext;
                    }
                    else {
                        b4statReceived.setText(offtext);
                        ba4 = offtext;
                    }
                }
                if (topic.equals("tgn/buttons/name/5")){
                    b5namReceived.setText(mqttMessage.toString()+":");
                    button5.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/buttons/status/5")){
                    if (mqttMessage.toString().equals("1")) {
                        b5statReceived.setText(ontext);
                        ba5 = ontext;
                    }
                    else {
                        b5statReceived.setText(offtext);
                        ba5 = offtext;
                    }
                }
                if (topic.equals("tgn/buttons/name/6")){
                    b6namReceived.setText(mqttMessage.toString()+":");
                    button6.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/buttons/status/6")){
                    if (mqttMessage.toString().equals("1")) {
                        b6statReceived.setText(ontext);
                        ba6 = ontext;
                    }
                    else {
                        b6statReceived.setText(offtext);
                        ba6 = offtext;
                    }
                }
                if (topic.equals("tgn/esp_1/connection/ip")){
                    eipReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/esp_1/temp/sensor_1")){
                    etempReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/esp_1/temp/sensor_2")){
                    ehumReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/esp_1/analog/sensor_1")){
                    elightReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/esp_2/analog/sensor_1")){
                    e2lightReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/esp_2/button/b1")){
                    if (mqttMessage.toString().equals("on")) {
                        e2pirReceived.setText("Rain");
                    }
                    else {
                        e2pirReceived.setText("No Rain");
                    }
                }
                if (topic.equals("tgn/esp_2/connection/ip")){
                    e2ipReceived.setText(mqttMessage.toString());
                }
                if (topic.equals("tgn/esp_2/temp/sensor_1")){
                    e2tempReceived.setText(mqttMessage.toString());
                }
            }
            @Override
            public void deliveryComplete(IMqttDeliveryToken iMqttDeliveryToken) {
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            Intent activityintent = new Intent(MainActivity.this, SettingsActivity.class);
            startActivityForResult(activityintent, sendid);
        }
        if (id == R.id.debug_window) {
            Intent activityintent = new Intent(MainActivity.this, DebugsActivity.class);
            startActivityForResult(activityintent, sendid);
        }
        return super.onOptionsItemSelected(item);
    }
}
